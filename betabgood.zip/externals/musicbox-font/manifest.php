<?php

 // 01.03.2013 - TrioxX

return array (
  'package' => 
  array (
    'type' => 'external',
    'name' => 'musicbox-font',
    'version' => '4.2.5',
	'revision' => '$Revision: 9729 $',
    'path' => 'externals/musicbox-font',
	'repository' => '',
    'title' => 'Musicbox Font',
    'author' => 'Webligo Developments',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
    ),
    'directories' => 
    array (
      0 => 'externals/musicbox-font',
    ),
  ),
); ?>