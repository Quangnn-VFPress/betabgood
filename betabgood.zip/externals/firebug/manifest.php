<?php

 // 01.03.2013 - TrioxX

return array(
  'package' => array(
    'type' => 'external',
    'name' => 'firebug',
    'version' => '4.0.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/firebug',
    'repository' => '',
    'title' => 'Firebug Lite',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/firebug',
    )
  )
) ?>