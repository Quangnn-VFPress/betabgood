<?php

 // 01.03.2013 - TrioxX

return array(
  'package' => array(
    'type' => 'external',
    'name' => 'flowplayer',
    'version' => '4.0.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/flowplayer',
    'repository' => '',
    'title' => 'Flow Player',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/flowplayer',
    )
  )
) ?>