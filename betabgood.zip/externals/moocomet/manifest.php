<?php

 // 01.03.2013 - TrioxX

return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocomet',
    'version' => '4.0.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moocomet',
    'repository' => '',
    'title' => 'Moocomet',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/moocomet',
    )
  )
) ?>