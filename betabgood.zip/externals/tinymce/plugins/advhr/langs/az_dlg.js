tinyMCE.addI18n('az.advhr_dlg',{
width:"Eni",
size:"H\u00FCnd\u00FCrl\u00FCy\u00FC",
noshade:"K\u00F6lg\u0259 yoxdur"
});