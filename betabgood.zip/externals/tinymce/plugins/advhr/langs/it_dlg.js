tinyMCE.addI18n('it.advhr_dlg',{
width:"Larghezza",
size:"Altezza",
noshade:"Senza ombreggiatura"
});