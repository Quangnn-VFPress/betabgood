tinyMCE.addI18n('ii.advhr_dlg',{
width:"\u5BBD",
size:"\u9AD8",
noshade:"\u65E0\u9634\u5F71"
});