tinyMCE.addI18n('ta.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});