tinyMCE.addI18n('ko.advhr_dlg',{
width:"\uD3ED",
size:"\uB192\uC774",
noshade:"\uADF8\uB9BC\uC790\uC5C6\uC74C"
});