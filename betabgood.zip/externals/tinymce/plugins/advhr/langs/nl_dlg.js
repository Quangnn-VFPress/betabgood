tinyMCE.addI18n('nl.advhr_dlg',{
width:"Breedte",
size:"Hoogte",
noshade:"Geen schaduw"
});