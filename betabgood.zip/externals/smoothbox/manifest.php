<?php

 // 01.03.2013 - TrioxX

return array(
  'package' => array(
    'type' => 'external',
    'name' => 'smoothbox',
    'version' => '4.2.2',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/smoothbox',
    'repository' => '',
    'title' => 'Smoothbox',
    'author' => 'Webligo Developments',
    'changeLog' => array(
      '4.2.2' => array(
        'manifest.php' => 'Incremented version',
        'smoothbox4.js' => 'Mootools 1.4 compatibility',
      ),
      '4.1.4' => array(
        'manifest.php' => 'Incremented version',
        'smoothbox4.js' => 'Fixed javascript errors in IE9',
      ),
    ),
    'directories' => array(
      'externals/smoothbox',
    )
  )
) ?>