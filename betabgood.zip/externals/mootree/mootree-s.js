

var MooTreeSControl = new Class({

    Extends: MooTreeControl

});

var MooTreeSNode = new Class({

  Extends: MooTreeNode

});
