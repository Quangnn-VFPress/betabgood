<?php

 // 01.03.2013 - TrioxX

return array(
  'package' => array(
    'type' => 'external',
    'name' => 'autocompleter',
    'version' => '4.1.4',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/autocompleter',
    'repository' => '',
    'title' => 'Autocompleter',
    'author' => 'Webligo Developments',
    'changeLog' => array(
      '4.1.4' => array(
        'Autocompleter.js' => 'Added option to ignore the overlay fix',
        'manifest.php' => 'Incremented version',
      ),
      '4.1.0' => array(
        'Autocompleter.js' => 'Resolved select/hover bug with Google Chrome; fixed tagging issues with Internet Explorer',
        'manifest.php' => 'Incremented version',
      ),
    ),
    'directories' => array(
      'externals/autocompleter',
    ),
  )
) ?>