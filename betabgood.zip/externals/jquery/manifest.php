<?php return array (
  'package' => 
  array (
    'type' => 'external',
    'name' => 'jquery',
    'version' => '4.0.0',
    'path' => 'externals/jquery',
    'title' => 'Jquery',
    'description' => 'Jquery ',
    'author' => 'Trung Nguyen',
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
    ),
    'directories' => 
    array (
      0 => 'externals/jquery',
    ),
  ),
); ?>